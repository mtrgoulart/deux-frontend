import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiFetch } from '../utils/api';
import MessageDisplay from './IndicatorManagement/MessageDisplay';

function StrategyCard({ 
  strategy, 
  onStatusChange, 
  onDelete, 
  getStatusBadge, 
  formatDate,
  loadingStatusChange 
}) {
  const [expanded, setExpanded] = useState(false);
  const [activeSection, setActiveSection] = useState('basic');

  // Fetch indicators for this strategy
  const { data: indicators = [] } = useQuery({
    queryKey: ['strategy_indicators', strategy.id],
    queryFn: async () => {
      const res = await apiFetch(`/select_indicators_by_user`);
      const data = await res.json();
      return data.indicators || [];
    },
    enabled: expanded,
  });

  // Get strategy configuration
  const { data: strategyConfig = {} } = useQuery({
    queryKey: ['strategy_config', strategy.strategy_buy, strategy.strategy_sell],
    queryFn: async () => {
      const res = await apiFetch('/get_strategies');
      const data = await res.json();
      const strategies = data.strategies || [];
      
      const buyStrategy = strategies.find(s => s.id === strategy.strategy_buy);
      const sellStrategy = strategies.find(s => s.id === strategy.strategy_sell);
      
      return {
        buy: buyStrategy || {},
        sell: sellStrategy || {}
      };
    },
    enabled: expanded,
  });

  const buyIndicators = indicators.filter(ind => ind.strategy_id === strategy.strategy_buy);
  const sellIndicators = indicators.filter(ind => ind.strategy_id === strategy.strategy_sell);

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      // You could add a toast notification here
      console.log('Copied to clipboard');
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const generateWebhookMessage = (type = 'all') => {
    const baseMessage = {
      symbol: strategy.symbol,
      strategy_id: strategy.id,
      action: type === 'buy' ? 'BUY' : type === 'sell' ? 'SELL' : 'SIGNAL'
    };
    
    return JSON.stringify(baseMessage, null, 2);
  };

  const sections = [
    { id: 'basic', label: 'Basic Info', icon: '📊' },
    { id: 'rules', label: 'Indicator Rules', icon: '⚙️' },
    { id: 'buy', label: 'BUY Indicators', icon: '📈' },
    { id: 'sell', label: 'SELL Indicator', icon: '📉' },
    { id: 'messages', label: 'Webhook Messages', icon: '🔗' }
  ];

  return (
    <div className="bg-gray-800 rounded-xl shadow-xl border border-gray-700 overflow-hidden transition-all duration-300 hover:shadow-2xl">
      {/* Strategy Header */}
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-lg">
                {strategy.name.charAt(0).toUpperCase()}
              </span>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white">{strategy.name}</h3>
              <p className="text-gray-400 text-sm">ID: {strategy.id}</p>
            </div>
          </div>
          {getStatusBadge(strategy.status)}
        </div>

        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-400">
            <span className="font-medium text-white">{strategy.symbol}</span> • 
            Created {formatDate(strategy.created_at)}
          </div>
          
          <div className="flex items-center space-x-2">
            {/* Control Buttons */}
            {strategy.status === 1 && (
              <button
                onClick={() => onStatusChange(strategy, 'start')}
                disabled={loadingStatusChange}
                className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white px-3 py-1 rounded text-sm transition-colors flex items-center space-x-1"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h1m4 0h1m6-6V7a2 2 0 00-2-2H5a2 2 0 00-2 2v3h14V7z" />
                </svg>
                <span>Start</span>
              </button>
            )}
            {strategy.status === 2 && (
              <button
                onClick={() => onStatusChange(strategy, 'stop')}
                disabled={loadingStatusChange}
                className="bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white px-3 py-1 rounded text-sm transition-colors flex items-center space-x-1"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10h6v4H9V10z" />
                </svg>
                <span>Stop</span>
              </button>
            )}
            
            {/* Expand/Collapse Button */}
            <button
              onClick={() => setExpanded(!expanded)}
              className="bg-cyan-600 hover:bg-cyan-700 text-white px-3 py-1 rounded text-sm transition-colors flex items-center space-x-1"
            >
              <svg className={`w-4 h-4 transition-transform ${expanded ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
              <span>{expanded ? 'Collapse' : 'Expand'}</span>
            </button>
            
            {/* Delete Button */}
            <button
              onClick={() => onDelete(strategy)}
              className="bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white px-3 py-1 rounded text-sm transition-colors border border-red-600/30"
            >
              Delete
            </button>
          </div>
        </div>
      </div>

      {/* Expanded Content */}
      {expanded && (
        <div className="p-6">
          {/* Section Navigation */}
          <div className="flex space-x-1 mb-6 bg-gray-900 p-1 rounded-lg">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeSection === section.id
                    ? 'bg-cyan-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                <span>{section.icon}</span>
                <span>{section.label}</span>
              </button>
            ))}
          </div>

          {/* Section Content */}
          <div className="min-h-[200px]">
            {activeSection === 'basic' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Strategy Name</label>
                    <div className="bg-gray-700 p-3 rounded-lg text-white">{strategy.name}</div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Trading Symbol</label>
                    <div className="bg-gray-700 p-3 rounded-lg text-white">{strategy.symbol}</div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Status</label>
                    <div className="bg-gray-700 p-3 rounded-lg">{getStatusBadge(strategy.status)}</div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Last Updated</label>
                    <div className="bg-gray-700 p-3 rounded-lg text-gray-300">{formatDate(strategy.updated_at)}</div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'rules' && (
              <div className="space-y-4">
                <div className="bg-gray-700 p-4 rounded-lg">
                  <h4 className="text-lg font-medium text-white mb-3">Indicator Management & Quantity Rules</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">BUY Strategy</label>
                      <div className="bg-gray-600 p-3 rounded text-white">
                        {strategyConfig.buy?.name || 'Loading...'}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">SELL Strategy</label>
                      <div className="bg-gray-600 p-3 rounded text-white">
                        {strategyConfig.sell?.name || 'Loading...'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-cyan-900/30 border border-cyan-500/50 rounded-lg">
                    <p className="text-cyan-200 text-sm">
                      💡 <strong>Indicator Rules:</strong> BUY signals require multiple indicators to agree, 
                      while SELL signals typically use a single indicator for quick exits.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'buy' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-medium text-white">BUY Indicators</h4>
                  <div className="bg-green-900/30 border border-green-500/50 px-3 py-1 rounded-full">
                    <span className="text-green-200 text-sm font-medium">
                      {buyIndicators.length} indicators configured
                    </span>
                  </div>
                </div>
                
                {buyIndicators.length > 0 ? (
                  <div className="space-y-2">
                    {buyIndicators.map((indicator, index) => (
                      <div key={indicator.id} className="bg-gray-700 p-3 rounded-lg flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="bg-green-600 text-white px-2 py-1 rounded text-xs font-medium">
                            BUY #{index + 1}
                          </span>
                          <span className="text-white">{indicator.name || `Indicator ${indicator.id}`}</span>
                          {indicator.mandatory && (
                            <span className="bg-red-500/20 text-red-400 px-2 py-1 rounded text-xs border border-red-500/30">
                              MANDATORY
                            </span>
                          )}
                        </div>
                        <div className="text-gray-400 text-sm">
                          Key: {indicator.indicator_key}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <svg className="w-12 h-12 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M7 11l5-5m0 0l5 5m-5-5v12" />
                    </svg>
                    <p>No BUY indicators configured</p>
                  </div>
                )}
              </div>
            )}

            {activeSection === 'sell' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-medium text-white">SELL Indicator</h4>
                  <div className="bg-red-900/30 border border-red-500/50 px-3 py-1 rounded-full">
                    <span className="text-red-200 text-sm font-medium">
                      {sellIndicators.length} indicator configured
                    </span>
                  </div>
                </div>
                
                {sellIndicators.length > 0 ? (
                  <div className="space-y-2">
                    {sellIndicators.map((indicator, index) => (
                      <div key={indicator.id} className="bg-gray-700 p-3 rounded-lg flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="bg-red-600 text-white px-2 py-1 rounded text-xs font-medium">
                            SELL #{index + 1}
                          </span>
                          <span className="text-white">{indicator.name || `Indicator ${indicator.id}`}</span>
                          {indicator.mandatory && (
                            <span className="bg-red-500/20 text-red-400 px-2 py-1 rounded text-xs border border-red-500/30">
                              MANDATORY
                            </span>
                          )}
                        </div>
                        <div className="text-gray-400 text-sm">
                          Key: {indicator.indicator_key}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <svg className="w-12 h-12 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 13l-5 5m0 0l-5-5m5 5V6" />
                    </svg>
                    <p>No SELL indicators configured</p>
                  </div>
                )}
              </div>
            )}

            {activeSection === 'messages' && (
              <MessageDisplay 
                strategy={strategy}
                buyIndicators={buyIndicators}
                sellIndicators={sellIndicators}
                copyToClipboard={copyToClipboard}
                generateWebhookMessage={generateWebhookMessage}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default StrategyCard;
