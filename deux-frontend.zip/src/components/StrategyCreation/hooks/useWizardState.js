import { useState, useCallback } from 'react';

const STEPS = {
  SYMBOL: 'symbol',
  RULES: 'rules',
  INDICATORS: 'indicators',
  REVIEW: 'review'
};

const STEP_ORDER = [STEPS.SYMBOL, STEPS.RULES, STEPS.INDICATORS, STEPS.REVIEW];

function useWizardState(initialStep = STEPS.SYMBOL) {
  const [currentStep, setCurrentStep] = useState(initialStep);
  const [completedSteps, setCompletedSteps] = useState([]);
  const [stepData, setStepData] = useState({
    [STEPS.SYMBOL]: {
      api_key: '',
      symbol: '',
      symbolData: null
    },
    [STEPS.RULES]: {
      mode: 'select', // 'select' or 'create'
      strategy_buy: '',
      strategy_sell: '',
      buyRuleData: null,
      sellRuleData: null,
      newBuyRule: {},
      newSellRule: {}
    },
    [STEPS.INDICATORS]: {
      buyIndicators: [],
      sellIndicators: []
    },
    [STEPS.REVIEW]: {
      strategyName: '',
      strategyDescription: ''
    }
  });

  // Navigation functions
  const goToStep = useCallback((step) => {
    if (STEP_ORDER.includes(step)) {
      setCurrentStep(step);
    }
  }, []);

  const nextStep = useCallback(() => {
    const currentIndex = STEP_ORDER.indexOf(currentStep);
    if (currentIndex < STEP_ORDER.length - 1) {
      const nextStepId = STEP_ORDER[currentIndex + 1];
      setCurrentStep(nextStepId);
    }
  }, [currentStep]);

  const prevStep = useCallback(() => {
    const currentIndex = STEP_ORDER.indexOf(currentStep);
    if (currentIndex > 0) {
      const prevStepId = STEP_ORDER[currentIndex - 1];
      setCurrentStep(prevStepId);
    }
  }, [currentStep]);

  const isFirstStep = currentStep === STEP_ORDER[0];
  const isLastStep = currentStep === STEP_ORDER[STEP_ORDER.length - 1];

  // Step completion tracking
  const markStepComplete = useCallback((step) => {
    setCompletedSteps(prev => {
      if (!prev.includes(step)) {
        return [...prev, step];
      }
      return prev;
    });
  }, []);

  const markStepIncomplete = useCallback((step) => {
    setCompletedSteps(prev => prev.filter(s => s !== step));
  }, []);

  const isStepComplete = useCallback((step) => {
    return completedSteps.includes(step);
  }, [completedSteps]);

  // Data management
  const updateStepData = useCallback((step, data) => {
    setStepData(prev => ({
      ...prev,
      [step]: {
        ...prev[step],
        ...data
      }
    }));
  }, []);

  const getStepData = useCallback((step) => {
    return stepData[step] || {};
  }, [stepData]);

  const getAllData = useCallback(() => {
    return stepData;
  }, [stepData]);

  // Step validation
  const validateStep = useCallback((step) => {
    const data = stepData[step];
    const errors = [];

    switch (step) {
      case STEPS.SYMBOL:
        if (!data.api_key) errors.push('API Key is required');
        if (!data.symbol) errors.push('Trading symbol is required');
        break;

      case STEPS.RULES:
        if (data.mode === 'select') {
          if (!data.strategy_buy) errors.push('Buy strategy is required');
          if (!data.strategy_sell) errors.push('Sell strategy is required');
        } else if (data.mode === 'create') {
          if (!data.newBuyRule.name) errors.push('Buy rule name is required');
          if (!data.newSellRule.name) errors.push('Sell rule name is required');
        }
        break;

      case STEPS.INDICATORS:
        if (data.buyIndicators.length === 0) {
          errors.push('At least one buy indicator is required');
        }
        if (data.sellIndicators.length === 0) {
          errors.push('At least one sell indicator is required');
        }
        break;

      case STEPS.REVIEW:
        if (!data.strategyName) errors.push('Strategy name is required');
        break;

      default:
        break;
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }, [stepData]);

  const canProceedToNext = useCallback(() => {
    const { isValid } = validateStep(currentStep);
    return isValid;
  }, [currentStep, validateStep]);

  // Reset functions
  const resetWizard = useCallback(() => {
    setCurrentStep(STEPS.SYMBOL);
    setCompletedSteps([]);
    setStepData({
      [STEPS.SYMBOL]: {
        api_key: '',
        symbol: '',
        symbolData: null
      },
      [STEPS.RULES]: {
        mode: 'select',
        strategy_buy: '',
        strategy_sell: '',
        buyRuleData: null,
        sellRuleData: null,
        newBuyRule: {},
        newSellRule: {}
      },
      [STEPS.INDICATORS]: {
        buyIndicators: [],
        sellIndicators: []
      },
      [STEPS.REVIEW]: {
        strategyName: '',
        strategyDescription: ''
      }
    });
  }, []);

  const resetStepData = useCallback((step) => {
    const defaultData = {
      [STEPS.SYMBOL]: {
        api_key: '',
        symbol: '',
        symbolData: null
      },
      [STEPS.RULES]: {
        mode: 'select',
        strategy_buy: '',
        strategy_sell: '',
        buyRuleData: null,
        sellRuleData: null,
        newBuyRule: {},
        newSellRule: {}
      },
      [STEPS.INDICATORS]: {
        buyIndicators: [],
        sellIndicators: []
      },
      [STEPS.REVIEW]: {
        strategyName: '',
        strategyDescription: ''
      }
    };

    setStepData(prev => ({
      ...prev,
      [step]: defaultData[step]
    }));
    markStepIncomplete(step);
  }, [markStepIncomplete]);

  // Progress calculation
  const getProgress = useCallback(() => {
    const currentIndex = STEP_ORDER.indexOf(currentStep);
    return {
      current: currentIndex + 1,
      total: STEP_ORDER.length,
      percentage: Math.round(((currentIndex + 1) / STEP_ORDER.length) * 100)
    };
  }, [currentStep]);

  return {
    // Current state
    currentStep,
    completedSteps,
    stepData,
    
    // Navigation
    goToStep,
    nextStep,
    prevStep,
    isFirstStep,
    isLastStep,
    
    // Step management
    markStepComplete,
    markStepIncomplete,
    isStepComplete,
    
    // Data management
    updateStepData,
    getStepData,
    getAllData,
    
    // Validation
    validateStep,
    canProceedToNext,
    
    // Reset
    resetWizard,
    resetStepData,
    
    // Progress
    getProgress,
    
    // Constants
    STEPS,
    STEP_ORDER
  };
}

export default useWizardState;
