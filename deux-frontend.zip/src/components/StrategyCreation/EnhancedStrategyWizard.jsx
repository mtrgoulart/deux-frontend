import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { v4 as uuidv4 } from 'uuid';
import { apiFetch } from '../../utils/api';

// Import hooks
import useWizardState from './hooks/useWizardState';

// Import UI components
import ProgressIndicator from './UI/ProgressIndicator';
import LoadingSpinner from './UI/LoadingSpinner';
import ValidationMessage from './UI/ValidationMessage';

// Import step components
import SymbolSelectionStep from './Steps/SymbolSelectionStep';
import RuleManagementStep from './Steps/RuleManagementStep';
import IndicatorConfigurationStep from './Steps/IndicatorConfigurationStep';
import ReviewStep from './Steps/ReviewStep';

function EnhancedStrategyWizard({ 
  showCreateForm, 
  setShowCreateForm, 
  onStrategyCreated 
}) {
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [stepValidation, setStepValidation] = useState({});

  // Initialize wizard state
  const {
    currentStep,
    completedSteps,
    stepData,
    goToStep,
    nextStep,
    prevStep,
    isFirstStep,
    isLastStep,
    updateStepData,
    getStepData,
    getAllData,
    validateStep,
    canProceedToNext,
    resetWizard,
    getProgress,
    STEPS,
    STEP_ORDER
  } = useWizardState();

  // Handle step validation changes
  const handleStepValidation = (stepId, isValid) => {
    setStepValidation(prev => ({
      ...prev,
      [stepId]: isValid
    }));
  };

  // Strategy creation mutation
  const createStrategyMutation = useMutation({
    mutationFn: async (strategyData) => {
      const res = await apiFetch('/save_instance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(strategyData),
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to create strategy');
      }
      
      return res.json();
    },
    onSuccess: (data) => {
      // Create indicators if any
      createIndicators(data.instance_id || data.id);
    },
    onError: (error) => {
      setSubmitError(error.message);
      setIsSubmitting(false);
    }
  });

  // Create indicators for the strategy
  const createIndicators = async (strategyId) => {
    try {
      const allData = getAllData();
      const allIndicators = [
        ...(allData.indicators?.buyIndicators || []),
        ...(allData.indicators?.sellIndicators || [])
      ];

      if (allIndicators.length > 0) {
        for (const indicator of allIndicators) {
          await apiFetch('/add_indicator', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              name: indicator.name,
              instance_id: strategyId,
              mandatory: indicator.mandatory,
              indicator_key: indicator.id,
              type: indicator.type
            })
          });
        }
      }

      // Success
      onStrategyCreated();
      resetWizard();
      setShowCreateForm(false);
      setIsSubmitting(false);
      setSubmitError(null);
    } catch (error) {
      console.error('Error creating indicators:', error);
      setSubmitError('Strategy created but failed to create indicators');
      setIsSubmitting(false);
    }
  };

  // Handle form submission
  const handleSubmit = async () => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const allData = getAllData();
      
      // Generate strategy data
      const strategyData = {
        name: allData.review?.strategyName,
        api_key: allData.symbol?.api_key,
        symbol: allData.symbol?.symbol,
        strategy_buy: allData.rules?.strategy_buy,
        strategy_sell: allData.rules?.strategy_sell,
        hash: uuidv4(),
        status: 1,
        created_at: new Date().toISOString(),
        description: allData.review?.strategyDescription || ''
      };

      await createStrategyMutation.mutateAsync(strategyData);
    } catch (error) {
      console.error('Submit error:', error);
      setSubmitError(error.message);
      setIsSubmitting(false);
    }
  };

  // Handle next step
  const handleNext = () => {
    const currentStepId = STEP_ORDER[STEP_ORDER.indexOf(currentStep)];
    const isValid = stepValidation[currentStepId];
    
    if (isValid) {
      if (isLastStep) {
        handleSubmit();
      } else {
        nextStep();
      }
    }
  };

  // Handle close
  const handleClose = () => {
    if (!isSubmitting) {
      resetWizard();
      setShowCreateForm(false);
      setSubmitError(null);
    }
  };

  // Get current step component
  const getCurrentStepComponent = () => {
    const stepProps = {
      stepData: getStepData(currentStep),
      updateStepData: (data) => updateStepData(currentStep, data),
      onValidationChange: (isValid) => handleStepValidation(currentStep, isValid)
    };

    switch (currentStep) {
      case STEPS.SYMBOL:
        return <SymbolSelectionStep {...stepProps} />;
      case STEPS.RULES:
        return <RuleManagementStep {...stepProps} />;
      case STEPS.INDICATORS:
        return <IndicatorConfigurationStep {...stepProps} />;
      case STEPS.REVIEW:
        return <ReviewStep {...stepProps} allWizardData={getAllData()} />;
      default:
        return <div className="text-center text-gray-400">Unknown step</div>;
    }
  };

  // Get step title
  const getStepTitle = () => {
    switch (currentStep) {
      case STEPS.SYMBOL: return 'Symbol Selection';
      case STEPS.RULES: return 'Rule Management';
      case STEPS.INDICATORS: return 'Indicator Configuration';
      case STEPS.REVIEW: return 'Review & Create';
      default: return 'Create Strategy';
    }
  };

  // Progress calculation
  const progress = getProgress();
  const canProceed = stepValidation[currentStep] && !isSubmitting;

  if (!showCreateForm) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-xl shadow-2xl w-full max-w-6xl max-h-[95vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-cyan-600 to-blue-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <span className="text-xl">🚀</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold">Enhanced Strategy Wizard</h2>
                <p className="text-cyan-100">{getStepTitle()}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-sm text-cyan-200">Progress</div>
                <div className="text-lg font-semibold">{progress.percentage}%</div>
              </div>
              <button
                onClick={handleClose}
                disabled={isSubmitting}
                className="text-white hover:bg-white/20 rounded-full p-2 transition-colors disabled:opacity-50"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* Progress Indicator */}
        <ProgressIndicator 
          currentStep={currentStep} 
          completedSteps={completedSteps}
        />

        {/* Content Area */}
        <div className="flex-1 overflow-hidden">
          <div className="h-full max-h-[60vh] overflow-y-auto p-6">
            {/* Loading Overlay */}
            {isSubmitting && (
              <div className="absolute inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-10">
                <div className="bg-gray-800 p-6 rounded-lg shadow-xl border border-gray-700">
                  <div className="flex flex-col items-center space-y-4">
                    <LoadingSpinner size="lg" />
                    <div className="text-center">
                      <p className="text-white font-medium">Creating Your Strategy</p>
                      <p className="text-gray-400 text-sm">Please wait while we set up your configuration...</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Error Display */}
            {submitError && (
              <div className="mb-6">
                <ValidationMessage 
                  type="error" 
                  message={submitError}
                />
              </div>
            )}

            {/* Step Content */}
            <div className="transition-all duration-300 ease-in-out">
              {getCurrentStepComponent()}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-900 px-6 py-4 border-t border-gray-700">
          <div className="flex items-center justify-between">
            {/* Previous Button */}
            <div>
              {!isFirstStep && (
                <button
                  onClick={prevStep}
                  disabled={isSubmitting}
                  className="bg-gray-600 hover:bg-gray-700 disabled:bg-gray-700 text-white px-6 py-3 rounded-lg transition-colors flex items-center space-x-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                  <span>Previous</span>
                </button>
              )}
            </div>

            {/* Step Info */}
            <div className="hidden sm:flex items-center space-x-2 text-sm text-gray-400">
              <span>Step {progress.current} of {progress.total}</span>
              <span>•</span>
              <span>{getStepTitle()}</span>
            </div>

            {/* Next/Submit Button */}
            <div className="flex items-center space-x-3">
              <button
                onClick={handleClose}
                disabled={isSubmitting}
                className="text-gray-400 hover:text-white px-4 py-3 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>

              <LoadingSpinner.Button
                onClick={handleNext}
                isLoading={isSubmitting}
                loadingText={isLastStep ? 'Creating Strategy...' : 'Processing...'}
                disabled={!canProceed}
                className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 ${
                  canProceed
                    ? isLastStep
                      ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg'
                      : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white shadow-lg'
                    : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                }`}
              >
                {isLastStep ? (
                  <>
                    <span>Create Strategy</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </>
                ) : (
                  <>
                    <span>Next</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </>
                )}
              </LoadingSpinner.Button>
            </div>
          </div>

          {/* Mobile Progress */}
          <div className="block sm:hidden mt-3 pt-3 border-t border-gray-700">
            <div className="flex items-center justify-between text-sm text-gray-400">
              <span>Step {progress.current} of {progress.total}</span>
              <span>{progress.percentage}% Complete</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
              <div 
                className="bg-gradient-to-r from-cyan-500 to-blue-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${progress.percentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EnhancedStrategyWizard;
