import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiFetch } from '../../utils/api';
import { v4 as uuidv4 } from 'uuid';

const STEPS = {
  BASIC: 'basic',
  RULES: 'rules', 
  INDICATORS: 'indicators',
  REVIEW: 'review'
};

function StrategyWizard({ showCreateForm, setShowCreateForm, onStrategyCreated }) {
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(STEPS.BASIC);
  const [formData, setFormData] = useState({
    name: '',
    api_key: '',
    symbol: '',
    strategy_buy: '',
    strategy_sell: '',
    status: 1
  });

  // Symbol search state
  const [symbolSearch, setSymbolSearch] = useState('');
  const [symbolSuggestions, setSymbolSuggestions] = useState([]);
  const [isSearchingSymbols, setIsSearchingSymbols] = useState(false);

  // Reset form when modal opens/closes
  const resetForm = () => {
    setFormData({
      name: '',
      api_key: '',
      symbol: '',
      strategy_buy: '',
      strategy_sell: '',
      status: 1
    });
    setCurrentStep(STEPS.BASIC);
    setSymbolSearch('');
    setSymbolSuggestions([]);
  };

  // Fetch data
  const { data: apiKeys = [] } = useQuery({
    queryKey: ['user_apikeys'],
    queryFn: async () => {
      const res = await apiFetch('/get_user_apikeys');
      const data = await res.json();
      return data.user_apikeys || [];
    },
  });

  const { data: strategies = [] } = useQuery({
    queryKey: ['strategies'],
    queryFn: async () => {
      const res = await apiFetch('/get_strategies');
      const data = await res.json();
      return data.strategies || [];
    },
  });

  // Symbol search with debounce
  const searchSymbols = async (searchTerm) => {
    if (!searchTerm || searchTerm.length < 2) {
      setSymbolSuggestions([]);
      return;
    }

    setIsSearchingSymbols(true);
    try {
      const res = await apiFetch(`/search_symbols?query=${encodeURIComponent(searchTerm)}`);
      const data = await res.json();
      setSymbolSuggestions(data.symbols || []);
    } catch (error) {
      console.error('Error searching symbols:', error);
      setSymbolSuggestions([]);
    } finally {
      setIsSearchingSymbols(false);
    }
  };

  const handleSymbolSearch = (value) => {
    setSymbolSearch(value);
    setFormData(prev => ({ ...prev, symbol: value }));
    
    // Debounce search
    setTimeout(() => {
      if (value === symbolSearch) {
        searchSymbols(value);
      }
    }, 300);
  };

  const selectSymbol = (symbol) => {
    setFormData(prev => ({ ...prev, symbol: symbol.symbol }));
    setSymbolSearch(symbol.symbol);
    setSymbolSuggestions([]);
  };

  // Create strategy mutation
  const createStrategyMutation = useMutation({
    mutationFn: async (strategyData) => {
      const res = await apiFetch('/save_instance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(strategyData),
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to create strategy');
      }
      
      return res.json();
    },
    onSuccess: () => {
      onStrategyCreated();
      resetForm();
      setShowCreateForm(false);
    },
    onError: (error) => {
      alert(`Error creating strategy: ${error.message}`);
    }
  });

  const handleSubmit = () => {
    // Generate unique hash for the strategy
    const strategyHash = uuidv4();
    
    const strategyData = {
      ...formData,
      hash: strategyHash,
      created_at: new Date().toISOString(),
    };

    createStrategyMutation.mutate(strategyData);
  };

  const canProceed = () => {
    switch (currentStep) {
      case STEPS.BASIC:
        return formData.name && formData.api_key && formData.symbol;
      case STEPS.RULES:
        return formData.strategy_buy && formData.strategy_sell;
      case STEPS.INDICATORS:
        return true; // Always can proceed from indicators
      case STEPS.REVIEW:
        return true; // Can submit from review
      default:
        return false;
    }
  };

  const nextStep = () => {
    const stepOrder = [STEPS.BASIC, STEPS.RULES, STEPS.INDICATORS, STEPS.REVIEW];
    const currentIndex = stepOrder.indexOf(currentStep);
    if (currentIndex < stepOrder.length - 1) {
      setCurrentStep(stepOrder[currentIndex + 1]);
    }
  };

  const prevStep = () => {
    const stepOrder = [STEPS.BASIC, STEPS.RULES, STEPS.INDICATORS, STEPS.REVIEW];
    const currentIndex = stepOrder.indexOf(currentStep);
    if (currentIndex > 0) {
      setCurrentStep(stepOrder[currentIndex - 1]);
    }
  };

  const getStepTitle = () => {
    switch (currentStep) {
      case STEPS.BASIC: return 'Basic Information';
      case STEPS.RULES: return 'Indicator Management & Quantity Rules';
      case STEPS.INDICATORS: return 'Configure Indicators';
      case STEPS.REVIEW: return 'Review & Generate';
      default: return 'Create Strategy';
    }
  };

  const getStepIcon = () => {
    switch (currentStep) {
      case STEPS.BASIC: return '📊';
      case STEPS.RULES: return '⚙️';
      case STEPS.INDICATORS: return '📈';
      case STEPS.REVIEW: return '✅';
      default: return '🚀';
    }
  };

  if (!showCreateForm) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-cyan-600 to-blue-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <span className="text-2xl">{getStepIcon()}</span>
              <div>
                <h2 className="text-2xl font-bold">Create New Strategy</h2>
                <p className="text-cyan-100">{getStepTitle()}</p>
              </div>
            </div>
            <button
              onClick={() => {
                setShowCreateForm(false);
                resetForm();
              }}
              className="text-white hover:bg-white/20 rounded-full p-2 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="bg-gray-900 px-6 py-4">
          <div className="flex items-center justify-between">
            {[
              { step: STEPS.BASIC, label: 'Basic', icon: '📊' },
              { step: STEPS.RULES, label: 'Rules', icon: '⚙️' },
              { step: STEPS.INDICATORS, label: 'Indicators', icon: '📈' },
              { step: STEPS.REVIEW, label: 'Review', icon: '✅' }
            ].map((item, index) => (
              <div key={item.step} className="flex items-center">
                <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  currentStep === item.step 
                    ? 'bg-cyan-600 text-white' 
                    : 'bg-gray-700 text-gray-300'
                }`}>
                  <span>{item.icon}</span>
                  <span className="hidden sm:inline">{item.label}</span>
                </div>
                {index < 3 && (
                  <svg className="w-4 h-4 text-gray-600 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[50vh] overflow-y-auto">
          {currentStep === STEPS.BASIC && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Strategy Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    placeholder="Enter strategy name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    API Key *
                  </label>
                  <select
                    value={formData.api_key}
                    onChange={(e) => setFormData(prev => ({ ...prev, api_key: e.target.value }))}
                    className="w-full bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    <option value="">Select API Key</option>
                    {apiKeys.map(key => (
                      <option key={key.api_key_id} value={key.api_key_id}>
                        ({key.api_key_id}) {key.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Trading Symbol *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={symbolSearch}
                    onChange={(e) => handleSymbolSearch(e.target.value)}
                    className="w-full bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    placeholder="Search for trading symbol (e.g., BTCUSDT)"
                  />
                  
                  {isSearchingSymbols && (
                    <div className="absolute right-3 top-3">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-cyan-500"></div>
                    </div>
                  )}

                  {symbolSuggestions.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-gray-700 border border-gray-600 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                      {symbolSuggestions.map((symbol, index) => (
                        <button
                          key={index}
                          onClick={() => selectSymbol(symbol)}
                          className="w-full text-left px-4 py-2 text-white hover:bg-gray-600 transition-colors"
                        >
                          <div className="font-medium">{symbol.symbol}</div>
                          {symbol.baseAsset && symbol.quoteAsset && (
                            <div className="text-sm text-gray-400">
                              {symbol.baseAsset}/{symbol.quoteAsset}
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {currentStep === STEPS.RULES && (
            <div className="space-y-6">
              <div className="bg-cyan-900/20 border border-cyan-500/50 p-4 rounded-lg">
                <h3 className="text-cyan-200 font-medium mb-2">📋 Indicator Management & Quantity Rules</h3>
                <p className="text-cyan-100 text-sm">
                  Select your BUY and SELL strategies. BUY strategies typically require multiple indicators 
                  to confirm entry signals, while SELL strategies use single indicators for quick exits.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    BUY Strategy (Entry Signals) *
                  </label>
                  <select
                    value={formData.strategy_buy}
                    onChange={(e) => setFormData(prev => ({ ...prev, strategy_buy: e.target.value }))}
                    className="w-full bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    <option value="">Select BUY strategy</option>
                    {strategies.map(strategy => (
                      <option key={strategy.id} value={strategy.id}>
                        {strategy.name}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-400 mt-1">
                    📈 Determines when to enter trades
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    SELL Strategy (Exit Signals) *
                  </label>
                  <select
                    value={formData.strategy_sell}
                    onChange={(e) => setFormData(prev => ({ ...prev, strategy_sell: e.target.value }))}
                    className="w-full bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    <option value="">Select SELL strategy</option>
                    {strategies.map(strategy => (
                      <option key={strategy.id} value={strategy.id}>
                        {strategy.name}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-400 mt-1">
                    📉 Determines when to exit trades
                  </p>
                </div>
              </div>
            </div>
          )}

          {currentStep === STEPS.INDICATORS && (
            <div className="space-y-6">
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Configure Indicators</h3>
                <p className="text-gray-400 mb-6">
                  After creating your strategy, you'll be able to configure individual indicators 
                  and set their parameters in the main strategies view.
                </p>
                <div className="bg-gray-700 p-4 rounded-lg text-left">
                  <h4 className="text-white font-medium mb-2">Next Steps:</h4>
                  <ul className="text-gray-300 text-sm space-y-1">
                    <li>• Configure BUY indicators and their requirements</li>
                    <li>• Set up SELL indicator parameters</li>
                    <li>• Mark mandatory indicators</li>
                    <li>• Generate and copy webhook messages</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {currentStep === STEPS.REVIEW && (
            <div className="space-y-6">
              <div className="bg-gray-700 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-white mb-4">Strategy Summary</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Strategy Name</label>
                    <div className="bg-gray-600 p-3 rounded text-white">{formData.name}</div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Trading Symbol</label>
                    <div className="bg-gray-600 p-3 rounded text-white">{formData.symbol}</div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">API Key</label>
                    <div className="bg-gray-600 p-3 rounded text-white">
                      {apiKeys.find(k => k.api_key_id === formData.api_key)?.name || formData.api_key}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Status</label>
                    <div className="bg-gray-600 p-3 rounded text-white">
                      <span className="bg-red-500/20 text-red-400 px-2 py-1 rounded text-xs">Stopped</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-gray-600">
                  <h4 className="text-white font-medium mb-2">Selected Strategies</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">BUY Strategy</label>
                      <div className="bg-gray-600 p-3 rounded text-white">
                        {strategies.find(s => s.id === formData.strategy_buy)?.name || 'None selected'}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">SELL Strategy</label>
                      <div className="bg-gray-600 p-3 rounded text-white">
                        {strategies.find(s => s.id === formData.strategy_sell)?.name || 'None selected'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-green-900/20 border border-green-500/50 p-4 rounded-lg">
                <div className="flex items-center space-x-2">
                  <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-green-200 font-medium">Ready to Create Strategy</span>
                </div>
                <p className="text-green-100 text-sm mt-1">
                  Your strategy will be created with these settings. You can modify indicators and webhook messages after creation.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-gray-900 px-6 py-4 flex items-center justify-between">
          <div>
            {currentStep !== STEPS.BASIC && (
              <button
                onClick={prevStep}
                className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                Previous
              </button>
            )}
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => {
                setShowCreateForm(false);
                resetForm();
              }}
              className="text-gray-400 hover:text-white px-4 py-2 transition-colors"
            >
              Cancel
            </button>
            
            {currentStep === STEPS.REVIEW ? (
              <button
                onClick={handleSubmit}
                disabled={createStrategyMutation.isLoading || !canProceed()}
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 disabled:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors flex items-center space-x-2"
              >
                {createStrategyMutation.isLoading ? (
                  <>
                    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Creating...</span>
                  </>
                ) : (
                  <>
                    <span>Create Strategy</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </>
                )}
              </button>
            ) : (
              <button
                onClick={nextStep}
                disabled={!canProceed()}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 disabled:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors flex items-center space-x-2"
              >
                <span>Next</span>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default StrategyWizard;
