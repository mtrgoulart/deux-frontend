import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiFetch } from '../utils/api';
import EnhancedStrategyWizard from '../components/StrategyCreation/EnhancedStrategyWizard';
import StrategyCard from '../components/StrategyCard';

function StrategiesPage() {
  const queryClient = useQueryClient();
  const [selectedApiKey, setSelectedApiKey] = useState(localStorage.getItem('selectedApiKey') || '');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [loadingStatusChange, setLoadingStatusChange] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [strategyToDelete, setStrategyToDelete] = useState(null);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [loadingDelete, setLoadingDelete] = useState(false);

  const handleStrategyStatusChange = async (strategy, action) => {
    if (
      (action === 'start' && strategy.status !== 1) ||
      (action === 'stop' && strategy.status !== 2)
    ) return;

    setLoadingStatusChange(true);
    setStatusMessage(action === 'start' ? 'Starting strategy...' : 'Stopping strategy...');

    try {
      await apiFetch(`/${action}_instance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instance_id: strategy.id })
      });

      setStatusMessage(action === 'start' ? '✅ Strategy started successfully!' : '🛑 Strategy stopped successfully!');
      await queryClient.invalidateQueries(['instances', selectedApiKey]);

      setTimeout(() => {
        setLoadingStatusChange(false);
        setStatusMessage('');
      }, 2000);
    } catch (err) {
      console.error(`Error ${action} strategy:`, err);
      setStatusMessage(`❌ Error ${action === 'start' ? 'starting' : 'stopping'} the strategy.`);
      setTimeout(() => {
        setLoadingStatusChange(false);
        setStatusMessage('');
      }, 3000);
    }
  };

  const handleDeleteStrategy = async () => {
    if (!strategyToDelete?.id) return;

    try {
      setConfirmDeleteOpen(false);
      setLoadingDelete(true);

      const res = await apiFetch('/remove_instance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instance_id: strategyToDelete.id })
      });

      const data = await res.json();

      if (res.ok) {
        await queryClient.invalidateQueries(['instances', selectedApiKey]);
      } else {
        alert(data.error || 'Error deleting the strategy.');
      }
    } catch (err) {
      console.error('Error deleting strategy:', err);
      alert('Error deleting the strategy.');
    } finally {
      setLoadingDelete(false);
      setStrategyToDelete(null);
    }
  };

  const { data: apiKeys = [] } = useQuery({
    queryKey: ['user_apikeys'],
    queryFn: async () => {
      const res = await apiFetch('/get_user_apikeys');
      const data = await res.json();
      const keys = data.user_apikeys || [];
      if (!selectedApiKey && keys.length > 0) {
        const defaultKey = keys[0].api_key_id;
        setSelectedApiKey(defaultKey);
        localStorage.setItem('selectedApiKey', defaultKey);
      }
      return keys;
    },
  });

  const { data: strategies = [], isLoading } = useQuery({
    queryKey: ['instances', selectedApiKey],
    queryFn: async () => {
      const res = await apiFetch(`/get_instances?api_key_id=${selectedApiKey}`);
      const data = await res.json();
      return data.instances || [];
    },
    enabled: !!selectedApiKey,
  });

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      1: { text: 'Stopped', color: 'bg-red-500/20 text-red-400 border-red-500/30' },
      2: { text: 'Running', color: 'bg-green-500/20 text-green-400 border-green-500/30' },
      3: { text: 'Paused', color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' }
    };
    
    const config = statusConfig[status] || { text: 'Unknown', color: 'bg-gray-500/20 text-gray-400 border-gray-500/30' };
    
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.color}`}>
        {config.text}
      </span>
    );
  };

  const onStrategyCreated = () => {
    queryClient.invalidateQueries(['instances', selectedApiKey]);
    setShowCreateForm(false);
  };

  return (
    <div className="p-6 text-white bg-gray-900 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Trading Strategies</h2>
          <p className="text-gray-400">Manage your automated trading strategies and configurations</p>
        </div>
        
        {statusMessage && (
          <div className="bg-gray-800 border border-gray-600 rounded-lg p-4 mb-4">
            <p className="text-sm">{statusMessage}</p>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-4 mb-6">
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Select API Key
          </label>
          <select
            value={selectedApiKey}
            onChange={(e) => {
              setSelectedApiKey(e.target.value);
              localStorage.setItem('selectedApiKey', e.target.value);
            }}
            className="bg-gray-800 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 min-w-64"
          >
            <option value="">Select an API Key</option>
            {apiKeys.map(key => (
              <option key={key.api_key_id} value={key.api_key_id}>
                ({key.api_key_id}) {key.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex-shrink-0 mt-7">
          <button 
            onClick={() => setShowCreateForm(true)} 
            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 shadow-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            <span>Create Strategy</span>
          </button>
        </div>
      </div>

      {/* Strategies Grid */}
      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
          <span className="ml-3 text-gray-400">Loading strategies...</span>
        </div>
      ) : strategies.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-24 h-24 mx-auto mb-4 text-gray-600">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-400 mb-2">No strategies found</h3>
          <p className="text-gray-500 mb-6">
            {selectedApiKey ? 'No trading strategies for this API key.' : 'Select an API key to view strategies.'}
          </p>
          {selectedApiKey && (
            <button 
              onClick={() => setShowCreateForm(true)}
              className="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-2 rounded-lg transition-colors"
            >
              Create Your First Strategy
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {strategies.map((strategy) => (
            <StrategyCard
              key={strategy.id}
              strategy={strategy}
              onStatusChange={handleStrategyStatusChange}
              onDelete={(strategy) => {
                setStrategyToDelete(strategy);
                setConfirmDeleteOpen(true);
              }}
              getStatusBadge={getStatusBadge}
              formatDate={formatDate}
              loadingStatusChange={loadingStatusChange}
            />
          ))}
        </div>
      )}

      {/* Enhanced Strategy Creation Wizard */}
      <EnhancedStrategyWizard
        showCreateForm={showCreateForm}
        setShowCreateForm={setShowCreateForm}
        onStrategyCreated={onStrategyCreated}
      />

      {/* Delete Confirmation Modal */}
      {confirmDeleteOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl w-full max-w-md">
            <h3 className="text-xl font-semibold mb-4 text-white">Confirm Delete</h3>
            <p className="text-gray-300 mb-6">
              Are you sure you want to delete the strategy "{strategyToDelete?.name}"? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => {
                  setConfirmDeleteOpen(false);
                  setStrategyToDelete(null);
                }}
                disabled={loadingDelete}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 disabled:bg-gray-700 text-white rounded transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteStrategy}
                disabled={loadingDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white rounded transition-colors flex items-center space-x-2"
              >
                {loadingDelete ? (
                  <>
                    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Deleting...</span>
                  </>
                ) : (
                  <span>Delete</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default StrategiesPage;
